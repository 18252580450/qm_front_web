function getUrl() {
    return {
        QM_URL: "http://127.0.0.1:8080",//质检前台url（本地测试）
        // QM_URL: "http://203.57.226.107:9990",//外网测试
        // QM_URL: "http://192.168.247.48:9990",//内网测试
    };
}